/* Includes **************************************************************** */
#include <algosensor.h>
#include <algobot.h>

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
OWI owi1(PC3,(uint8_t *)& PINC,(uint8_t *)& PORTC,(uint8_t *)& DDRC);
OWI owi2(PC2,(uint8_t *)& PINC,(uint8_t *)& PORTC,(uint8_t *)& DDRC);
AlgoSensor Sensor1(SENSOR_A_PIN,&owi1);
AlgoSensor Sensor2(SENSOR_B_PIN,&owi2);

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoSensor::AlgoSensor(uint8_t pin, OWI * owi) 
{
    this->pin = pin;
    this->owi = owi;
    pinMode(pin, INPUT);
}


uint8_t AlgoSensor::getValue() 
{
    float dutyCycle = 0;
    uint8_t value = 0;
    if(this->type == ALGOSENSOR_TYPE_1WIRE)
    {
        if(digitalRead(pin) == 0) 
        {
            this->type = ALGOSENSOR_TYPE_PWM;
            Serial.println("PWM device detected\n");
            return 0;
        }
        this->owi->readValue(0xbe,&value);
    }
    else
    {
        unsigned long pwmHighValue = pulseIn(pin, HIGH, PULSE_TIMEOUT);
        if(pwmHighValue != 0) 
        {
            dutyCycle = (float(pwmHighValue) / CYCLE_TIME) * 100.0f;
        } 
        else if (digitalRead(pin)) 
        {
            /* dutyCycle = 100; */
            this->type = ALGOSENSOR_TYPE_1WIRE;
            dutyCycle = 0;
            Serial.println("1Wire device detected\n");
        } 
        else 
        {
            dutyCycle = 0;
        }
        value = uint8_t(round(dutyCycle / 10));
    }
    /* Serial.print("Value:"); */
    /* Serial.println(value); */
    return value;
}


uint8_t Sensor(AlgoSensor & sensor)
{
    return sensor.getValue();
}
uint8_t Sensor(uint8_t port)
{
    switch(port)
    {
        case(1):
        {
            return Sensor1.getValue();
            break;
        }
        case(2):
        {
            return Sensor2.getValue();
            break;
        }
        default:
        {

        }
    }
}

uint8_t waitSensor(uint8_t port, int8_t value)
{
    uint8_t cvalue;
    if(value <= FALSE )
    {
        while(1)
        {
            cvalue = Sensor(port);

            if((cvalue == 0) && (value == FALSE))
            {
                break;
            }
            else if((cvalue != 0) && (value == TRUE))
            {
                break;
            }
            delay(50);
        }
        delay(10);
        return cvalue;
    }
    else
    {
        while(1)
        {
            cvalue = Sensor(port);
            if(cvalue == value)
            {
                break; 
            }
            delay(50);
        }
        return cvalue;
    }
}
uint8_t waitSensor(uint8_t port, uint8_t min_value, uint8_t max_value)
{
    uint8_t cvalue;
    while(1)
    {
        delay(10);
        cvalue = Sensor(port);
		Serial.print("Value from function: ");
		Serial.println(cvalue);
        if((cvalue >= min_value) && (cvalue <= max_value))
        {
           break; 
        }
    }
    return cvalue;

}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
