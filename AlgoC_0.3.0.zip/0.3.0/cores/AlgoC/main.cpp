/*
  main.cpp - Main loop for Arduino sketches
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <Arduino.h>
#include <systim.h>
#include <compileTime.h>
#include <../../libraries/Algobrix/algothread.h>
/* #include <../../libraries/Algobrix/algobot.h> */
#include <EEPROM.h>
#include <version.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <../../libraries/Algobrix/softserial.h>

#define R1 20000.0 // resistance of R1 (20K)
#define R2 10000.0 // resistance of R2 (10K)

// Declared weak in Arduino.h to allow user redefinitions.
int atexit(void (* /*func*/ )()) { return 0; }

// Weak empty variant initialization function.
// May be redefined by variant files.
void initVariant() __attribute__((weak));
void initVariant() { }

void chkALGOBOT() __attribute__((weak));
void chkALGOBOT() { }

void stopALGOBOT() __attribute__((weak));
void stopALGOBOT() { }
void initALGOBOT() __attribute__((weak));
void initALGOBOT() { }

void setup() __attribute__((weak));
void setup() { }

void loop() __attribute__((weak));
void loop() { }

/* void application(ALGOC) { } */
 /* __attribute__((weak)) */
//void setupUSB() __attribute__((weak));
//void setupUSB() { }

uint16_t getBatteryVoltage(void);


uint8_t g_playState = 0x00;
uint32_t g_playTimer;

enum PLAY_BUTTON_STATE
{
	PLAY_BUTTON_STATE_IDLE = 0x00,
	PLAY_BUTTON_STATE_LOW,
	PLAY_BUTTON_STATE_HIGH,
};

uint8_t g_playButtonState;
uint32_t g_playButtonTimer;
uint32_t g_battery_voltage_print;
volatile uint8_t g_runFlag = 0x00;
volatile uint8_t g_upload_flag = 0x00;

static uint8_t chkBTN(void);

ISR(PCINT1_vect) 
{

    if (!(PINC & (1 << PC0)))
    { 
        if(g_ALGOBOT_INFO.state == ALGOBOT_STATE_RUN)
        {
            g_ALGOBOT_INFO.state = ALGOBOT_STATE_HALT;
            asm("jmp label_algobot_stop");
        }
        else
        {
            g_ALGOBOT_INFO.state = ALGOBOT_STATE_IDLE;
        }
    }
}

int main(void)
{
    init();


    initVariant();
    initALGOBOT();

	time_t t;
	srand((unsigned) time(&t));

    PCMSK1 |= 0x00; //PCINT8 PD5 C0
    PCIFR = 0b00000000; //Clear all flags
    PCICR |= 0x02; //Turn on port C PCIE2

#if defined(USBCON)
    USBDevice.attach();
#endif

// #define bleSerial Serial1
    setup();
    Serial.begin(115200);
	SoftSerial bleSerial(11);
	bleSerial.begin(115200);

	delay(100);
	bleSerial.write(0xf0);
	for(uint8_t i=1; i<9; i++) 
	{
		bleSerial.write(i);
	}

	delay(100);
	bleSerial.write(0x0F);
	for(uint8_t i=1; i<9; i++) 
	{
		bleSerial.write(i);
	}
	delay(100);
	uint8_t prevButtonState = digitalRead(PLAY_BUTTON_PIN);
    uint8_t buttonState = prevButtonState;
    uint8_t batteryError = 0x00;
    uint8_t batteryState = 0x00;
    uint32_t batteryTimer = getSYSTIM();
    g_playTimer = getSYSTIM();
    uint32_t voltage;

	g_playState = 0x00;
    pinMode(POWER_LED_PIN,OUTPUT);
	digitalWrite(PLAY_LED_PIN,g_playState);

	uint32_t eepromBuildTime;
	eepromBuildTime = EEPROM.read(0);
	eepromBuildTime = (eepromBuildTime << 8) | EEPROM.read(1);
	eepromBuildTime = (eepromBuildTime << 8) | EEPROM.read(2);
	eepromBuildTime = (eepromBuildTime << 8) | EEPROM.read(3);
	/* Serial.print("Build itme: "); */
	/* Serial.println(c_current_build_time,HEX); */
	/* Serial.print("EEPROM Build itme: "); */
	/* Serial.println(eepromBuildTime,HEX); */
    delay(1000);
   	if(eepromBuildTime != c_current_build_time)
	{
		g_upload_flag = 1;
		g_runFlag = 1;
		EEPROM.write(0,(c_current_build_time >> 24) & 0xff);
		EEPROM.write(1,(c_current_build_time >> 16) & 0xff);
		EEPROM.write(2,(c_current_build_time >> 8) & 0xff);
		EEPROM.write(3,c_current_build_time & 0xff);
		/* Serial.println("Save build to EEPROM"); */
	}

    voltage = getBatteryVoltage();
    Serial.print("Device started. Batter voltage is ");
    Serial.println(voltage);
    if(voltage < 7000)
    {
        g_upload_flag = 0;
        g_playState = 0x01;
        digitalWrite(PLAY_LED_PIN,g_playState);
    }



    for (;;) 
    {
        voltage = getBatteryVoltage();
        buttonState = chkBTN();
        if(chk4TimeoutSYSTIM(batteryTimer,200) == SYSTIM_TIMEOUT)
        {
            batteryTimer = getSYSTIM();
			if(g_runFlag != 0)
			{
				if(voltage > 7500)
				{
					if(batteryState != 0x00)
					{
						batteryState == 0x00;
						digitalWrite(POWER_LED_PIN,batteryState);
					}
				}
				else if(voltage > 7000)
				{
					if(batteryState != 0x01)
					{
						batteryState = 0x01;
						digitalWrite(POWER_LED_PIN,batteryState);
					}
				}
				else
				{
					batteryState ^= 0x01;
					digitalWrite(POWER_LED_PIN,batteryState);
				}
			}
        }

		
        if(((voltage > 7000) && ((buttonState == 0) && (g_runFlag == 1))) || (g_upload_flag != 0x00))
        {
			g_upload_flag = 0;
            g_ALGOBOT_INFO.state = ALGOBOT_STATE_RUN;
            PCMSK1 |= 0x01;
            digitalWrite(PLAY_LED_PIN,0);

			chkALGOBOT();
			application(threadAlgoC);
			// loop();
			if(chk4TimeoutSYSTIM(g_playTimer,200) == SYSTIM_TIMEOUT)
			{
				g_playState ^= 0x01;
				g_playTimer = getSYSTIM();
				digitalWrite(PLAY_LED_PIN,g_playState);
			}
			if(g_ALGOBOT_INFO.state == ALGOBOT_STATE_RUN)
			{
				// g_ALGOBOT_INFO.state = ALGOBOT_STATE_WAIT4STOP;
				g_ALGOBOT_INFO.state = ALGOBOT_STATE_IDLE;
				g_playState = 0x01;
				pinMode(PLAY_LED_PIN,OUTPUT);
				digitalWrite(PLAY_LED_PIN,g_playState);
				// while(g_ALGOBOT_INFO.state != ALGOBOT_STATE_IDLE)
				// {

				// }
			}
			asm("label_algobot_stop:");
			PCMSK1 &= ~(0x01);

			g_playButtonTimer = getSYSTIM();
			stopALGOBOT();
			while(digitalRead(PLAY_BUTTON_PIN) == 0)
			{
				if(chk4TimeoutSYSTIM(g_playButtonTimer,3000) == SYSTIM_TIMEOUT)
				{
					stopALGOBOT();
					pinMode(PLAY_BUTTON_PIN,OUTPUT);
					digitalWrite(PLAY_BUTTON_PIN,HIGH);
					g_runFlag = 0;
					digitalWrite(PLAY_LED_PIN,0x00);
					digitalWrite(POWER_LED_PIN,0x00);
				}
			}
			if(g_runFlag)
			{
				g_playState = 0x01;
				digitalWrite(PLAY_LED_PIN,g_playState);
			}
		}
		if((voltage > 7000) && (buttonState == 0) && (g_runFlag == 0))
		{

			g_runFlag = 1;
			digitalWrite(PLAY_LED_PIN,0x01);
			while(digitalRead(PLAY_BUTTON_PIN) == 0)
			{

			}
		}
        else if((buttonState == 0) && (voltage <= 7000))
        {
            if(chk4TimeoutSYSTIM(g_battery_voltage_print,2000) == SYSTIM_TIMEOUT)
            {
                g_battery_voltage_print = getSYSTIM();
                Serial.print("Button press detected, but voltage is to low: ");
                Serial.println(voltage);
            }
		}
			
        if (serialEventRun) serialEventRun();
    }
    return 0;
}

uint16_t getBatteryVoltage(void)
{
    uint32_t vout = 0.0;
    uint32_t vin = 0.0;
    pinMode(PLAY_BUTTON_PIN,OUTPUT);
    digitalWrite(PLAY_BUTTON_PIN,HIGH);
	uint32_t timer = getSYSTIM();
	while(chk4TimeoutSYSTIM(timer,5) == SYSTIM_KEEP_ALIVE)
	{

	}
    digitalWrite(PLAY_BUTTON_PIN,LOW);
    pinMode(PLAY_BUTTON_PIN,INPUT);
    vout = analogRead(POWER_METER_PIN);
    vout = (vout * 5000) / 1024;
    vin = vout / (R2 / (R1 + R2));
    return vin;
}

uint8_t chkBTN(void)
{
	switch(g_playButtonState)
	{
		case (PLAY_BUTTON_STATE_IDLE):
		{
			if(digitalRead(PLAY_BUTTON_PIN) == 0)
			{
				g_playButtonState = PLAY_BUTTON_STATE_LOW;
				g_playButtonTimer = getSYSTIM();
			}
			break;
		}
		case (PLAY_BUTTON_STATE_LOW):
		{
			if(chk4TimeoutSYSTIM(g_playButtonTimer,3000) == SYSTIM_TIMEOUT)
			{
				stopALGOBOT();
				pinMode(PLAY_BUTTON_PIN,OUTPUT);
				digitalWrite(PLAY_BUTTON_PIN,HIGH);
				g_runFlag = 0;
				digitalWrite(PLAY_LED_PIN,0x00);
				while(digitalRead(PLAY_BUTTON_PIN) == 0)
				{

				}
			}
			if(digitalRead(PLAY_BUTTON_PIN) != 0)
			{
				Serial.println("Button is pressed");
				g_playButtonState = PLAY_BUTTON_STATE_IDLE;
				return 0;
			}
			return 1;
			break;
		}
		case (PLAY_BUTTON_STATE_HIGH):
		{
			break;
		}

	}
	return 1;
}
