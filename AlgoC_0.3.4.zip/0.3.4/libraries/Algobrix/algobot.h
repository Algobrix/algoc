/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOBOT_H
#define __ALGOBOT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include "systim.h"
#include <compileTime.h>
#include <algothread.h>
#include <algolight.h>
#include <algomotor.h>
#include <algobot.h>
#include <algosound.h>
#include <algowait.h>
#include <algosensor.h>
#include <algobreak.h>
#include <algothread.h>

/* Exported constants ****************************************************** */


/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */
void initALGOBOT(void);
void stopALGOBOT(void);

#endif 
/* ***************************** END OF FILE ******************************* */

