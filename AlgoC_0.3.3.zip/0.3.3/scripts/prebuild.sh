#!/bin/bash
build="$1"
file="$2"
echo "$build" >> "$file"
