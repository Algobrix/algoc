/* Includes **************************************************************** */
#include "algowait.h"
#include "algobot.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
void Wait(System Name,float second)
{
	if(Name.cthread.sequance != Name.sequance)
	{
		return;
	}
	yield();
	switch(Name.cthread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			Serial.print("Wait on line [");
			Serial.print(Name.line);
			Serial.print("] for [");
			Serial.print(second);
			Serial.println("] seconds");
			Name.cthread.waitTimer = getSYSTIM();
            Name.cthread.waitPeriod = second * 1000;
			if(&Name.cthread == &threadAlgoC)
			{
				while(chk4TimeoutSYSTIM(Name.cthread.waitTimer,Name.cthread.waitPeriod) == SYSTIM_KEEP_ALIVE)
				{
					yield();
					if(g_ALGOBOT_INFO.state != ALGOBOT_STATE_RUN)
					{
						Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
						return;
					}
				}
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				return;
			}
			else
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
				return;
			}
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			if(chk4TimeoutSYSTIM(Name.cthread.waitTimer,Name.cthread.waitPeriod))
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				return;
			}
			return;
			break;
		}
	}
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
