/* Includes **************************************************************** */
#include "algobot.h"
#include "algothread.h"

/* Private types *********************************************************** */

/* Private constants ******************************************************* */

/* Private macros ********************************************************** */

/* Private variables ******************************************************* */

AlgoThread thread0;
AlgoThread thread1;
AlgoThread thread2;
AlgoThread thread3;
AlgoThread thread4;
AlgoThread thread5;
AlgoThread thread6;
AlgoThread thread7;
AlgoThread thread8;
AlgoThread thread9;
AlgoThread thread10;
AlgoThread thread11;
AlgoThread thread12;
AlgoThread thread13;
AlgoThread thread14;
AlgoThread thread15;
AlgoThread thread16;
AlgoThread thread17;
AlgoThread thread18;
AlgoThread thread19;
AlgoThread thread20;
AlgoThread thread21;
AlgoThread thread22;
AlgoThread thread23;
AlgoThread thread24;
AlgoThread thread25;
AlgoThread thread26;
AlgoThread thread27;
AlgoThread thread28;
AlgoThread thread29;
AlgoThread thread30;
AlgoThread thread31;

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */

void initTHREADS(void)
{

}
void chkTHREADS(void)
{
	thread0_run();
	thread1_run();
	thread2_run();
	thread3_run();
	thread4_run();
	thread5_run();
	thread6_run();
	thread7_run();
	thread8_run();
	thread9_run();
	thread10_run();
	thread11_run();
	thread12_run();
	thread13_run();
	thread14_run();
	thread15_run();
	thread16_run();
	thread17_run();
	thread18_run();
	thread19_run();
	thread20_run();
	thread21_run();
	thread22_run();
	thread23_run();
	thread24_run();
	thread25_run();
	thread26_run();
	thread27_run();
	thread28_run();
	thread29_run();
	thread30_run();
	thread31_run();
}
void thread0_run(void)
{ 
	application();
}


void thread1_run(void)
{ 

}

void thread2_run(void)
{ 

}

void thread3_run(void)
{ 

}
void thread4_run(void)
{ 

}
void thread5_run(void)
{ 

}
void thread6_run(void)
{ 

}
void thread7_run(void)
{ 

}
void thread8_run(void)
{ 

}
void thread9_run(void)
{ 

}
void thread10_run(void)
{ 

}
void thread11_run(void)
{ 

}
void thread12_run(void)
{ 

}
void thread13_run(void)
{ 

}
void thread14_run(void)
{ 

}
void thread15_run(void)
{ 

}
void thread16_run(void)
{ 

}
void thread17_run(void)
{ 

}
void thread18_run(void)
{ 

}
void thread19_run(void)
{ 

}
void thread20_run(void)
{ 

}
void thread21_run(void)
{ 

}
void thread22_run(void)
{ 

}
void thread23_run(void)
{ 

}
void thread24_run(void)
{ 

}
void thread25_run(void)
{ 

}
void thread26_run(void)
{ 

}
void thread27_run(void)
{ 

}
void thread28_run(void)
{ 

}
void thread29_run(void)
{ 

}
void thread30_run(void)
{ 

}
void thread31_run(void)
{ 

}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */


