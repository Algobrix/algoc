/**
* @file        algothread.h
* @author      semir-t
* @date        Maj 2023
* @version     1.0.0
*/

/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOTHREAD_H
#define __ALGOTHREAD_H
/* Includes **************************************************************** */
#include <Arduino.h>

/* Module configuration **************************************************** */
#define THREAD_CNT					32

/* Exported constants ****************************************************** */
enum ALGOTHREAD_STATE
{
	ALGOTHREAD_STATE_CONTINUE = 0x00,
	ALGOTHREAD_STATE_RUNNING,
};
/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoThread
{
	private:

	public:
		uint8_t state;
		uint32_t id;
		uint32_t line;
};


/* Exported variables ****************************************************** */
extern AlgoThread thread0;
extern AlgoThread thread1;
extern AlgoThread thread2;
extern AlgoThread thread3;
extern AlgoThread thread4;
extern AlgoThread thread5;
extern AlgoThread thread6;
extern AlgoThread thread7;
extern AlgoThread thread8;
extern AlgoThread thread9;
extern AlgoThread thread10;
extern AlgoThread thread11;
extern AlgoThread thread12;
extern AlgoThread thread13;
extern AlgoThread thread14;
extern AlgoThread thread15;
extern AlgoThread thread16;
extern AlgoThread thread17;
extern AlgoThread thread18;
extern AlgoThread thread19;
extern AlgoThread thread20;
extern AlgoThread thread21;
extern AlgoThread thread22;
extern AlgoThread thread23;
extern AlgoThread thread24;
extern AlgoThread thread25;
extern AlgoThread thread26;
extern AlgoThread thread27;
extern AlgoThread thread28;
extern AlgoThread thread29;
extern AlgoThread thread30;
extern AlgoThread thread31;

/* Exported functions ****************************************************** */
void chkTHREADS(void);
void initTHREADS(void);

void thread0_run(void) __attribute__((weak));
void thread1_run(void) __attribute__((weak));
void thread2_run(void) __attribute__((weak));
void thread3_run(void) __attribute__((weak));
void thread4_run(void) __attribute__((weak));
void thread5_run(void) __attribute__((weak));
void thread6_run(void) __attribute__((weak));
void thread7_run(void) __attribute__((weak));
void thread8_run(void) __attribute__((weak));
void thread9_run(void) __attribute__((weak));
void thread10_run(void) __attribute__((weak));
void thread11_run(void) __attribute__((weak));
void thread12_run(void) __attribute__((weak));
void thread13_run(void) __attribute__((weak));
void thread14_run(void) __attribute__((weak));
void thread15_run(void) __attribute__((weak));
void thread16_run(void) __attribute__((weak));
void thread17_run(void) __attribute__((weak));
void thread18_run(void) __attribute__((weak));
void thread19_run(void) __attribute__((weak));
void thread20_run(void) __attribute__((weak));
void thread21_run(void) __attribute__((weak));
void thread22_run(void) __attribute__((weak));
void thread23_run(void) __attribute__((weak));
void thread24_run(void) __attribute__((weak));
void thread25_run(void) __attribute__((weak));
void thread26_run(void) __attribute__((weak));
void thread27_run(void) __attribute__((weak));
void thread28_run(void) __attribute__((weak));
void thread29_run(void) __attribute__((weak));
void thread30_run(void) __attribute__((weak));
void thread31_run(void) __attribute__((weak));

#endif 

