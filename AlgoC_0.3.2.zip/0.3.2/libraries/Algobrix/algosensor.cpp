/* Includes **************************************************************** */
#include <algosensor.h>
#include <algobot.h>

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
OWI owi1(PC3,(uint8_t *)& PINC,(uint8_t *)& PORTC,(uint8_t *)& DDRC);
OWI owi2(PC2,(uint8_t *)& PINC,(uint8_t *)& PORTC,(uint8_t *)& DDRC);
AlgoSensor Sensor1(SENSOR_A_PIN,&owi1);
AlgoSensor Sensor2(SENSOR_B_PIN,&owi2);

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoSensor::AlgoSensor(uint8_t pin, OWI * owi) 
{
    this->pin = pin;
    this->owi = owi;
    pinMode(pin, INPUT);
}


uint8_t AlgoSensor::getValue() 
{
    float dutyCycle = 0;
    uint8_t value = 0;
    if(this->type == ALGOSENSOR_TYPE_1WIRE)
    {
        if(digitalRead(pin) == 0) 
        {
            this->type = ALGOSENSOR_TYPE_PWM;
            Serial.println("PWM device detected\n");
            return 0;
        }
        this->owi->readValue(0xbe,&value);
    }
    else
    {
        unsigned long pwmHighValue = pulseIn(pin, HIGH, PULSE_TIMEOUT);
        if(pwmHighValue != 0) 
        {
            dutyCycle = (float(pwmHighValue) / CYCLE_TIME) * 100.0f;
        } 
        else if (digitalRead(pin)) 
        {
            /* dutyCycle = 100; */
            this->type = ALGOSENSOR_TYPE_1WIRE;
            dutyCycle = 0;
            Serial.println("1Wire device detected\n");
        } 
        else 
        {
            dutyCycle = 0;
        }
        value = uint8_t(round(dutyCycle / 10));
    }
    /* Serial.print("Value:"); */
    /* Serial.println(value); */
    return value;
}


uint8_t Sensor(AlgoSensor & sensor)
{
    return sensor.getValue();
}
uint8_t Sensor(uint8_t port)
{
    switch(port)
    {
        case('1'):
        case(1):
        {
            return Sensor1.getValue();
            break;
        }
        case('2'):
        case(2):
        {
            return Sensor2.getValue();
            break;
        }
        default:
        {

        }
    }
}


void WaitSensor(System Name,int sensorPort, int signalValue)
{
	if(Name.cthread.sequance != Name.sequance)
	{
		return;
	}
	yield();
    uint8_t cvalue;
	switch(Name.cthread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			Serial.print("Wait for sensor on line [");
			Serial.print(Name.line);
			Serial.print("] for value in range [");
			if(signalValue)
			{
				Serial.print("True");
			}
			else
			{
				Serial.print("False");
			}
			Serial.println("]");
			Name.cthread.waitTimer = getSYSTIM();
			if(&Name.cthread == &threadAlgoC)
			{
				while(1)
				{
					delay(10);
					yield();
					cvalue = Sensor(sensorPort);
					if(cvalue != 0x00)
					{
						break;
					}
					if(g_ALGOBOT_INFO.state != ALGOBOT_STATE_RUN)
					{
						Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
						return;
					}
				}
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				return;
			}
			else
			{
				// cthread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
				return;
			}
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			cvalue = Sensor(sensorPort);
			if(cvalue != 0x00)
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				return;
			}
			return;
			break;
		}
	}
}

uint8_t WaitSensor(System Name,int sensorPort, int minSignalValue, int maxSignalValue)
{
	if(Name.cthread.sequance != Name.sequance)
	{
		return 0xff;
	}
	yield();
    uint8_t cvalue;
	switch(Name.cthread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			Serial.print("Wait for sensor on line [");
			Serial.print(Name.line);
			Serial.print("] for value in range [");
			Serial.print(minSignalValue);
			Serial.print("-");
			Serial.print(maxSignalValue);
			Serial.println("]");
			Name.cthread.waitTimer = getSYSTIM();
			if(&Name.cthread == &threadAlgoC)
			{
				while(1)
				{
					delay(10);
					yield();
					cvalue = Sensor(sensorPort);
					Serial.print("Current sensor value: ");
					Serial.println(cvalue);
					if((cvalue >= minSignalValue) && (cvalue <= maxSignalValue))
					{
						break;
					}
				}
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				// return OP_STATUS_COMPLETED;
				return cvalue;
			}
			else
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
				// return OP_STATUS_RUNNING;
				return 0xff;
			}
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			cvalue = Sensor(sensorPort);
			if((cvalue >= minSignalValue) && (cvalue <= maxSignalValue))
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				// return OP_STATUS_COMPLETED;
				return cvalue;
			}
			return 0xff;
			break;
		}
	}
}


/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
