/* Includes **************************************************************** */
#include <algosensor.h>
#include <algobot.h>

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
AlgoSensor Sensor1(SENSOR_A_PIN);
AlgoSensor Sensor2(SENSOR_B_PIN);

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoSensor::AlgoSensor(uint8_t pin) 
{
    this->pin = pin;
    pinMode(pin, INPUT);
}


uint8_t AlgoSensor::getValue() 
{
    float dutyCycle = 0;
    unsigned long pwmHighValue = pulseIn(pin, HIGH, PULSE_TIMEOUT);
    if(pwmHighValue != 0) 
    {
        dutyCycle = (float(pwmHighValue) / CYCLE_TIME) * 100.0f;
    } 
    else if (digitalRead(pin)) 
    {
        dutyCycle = 100;
    } 
    else 
    {
        dutyCycle = 0;
    }
    uint8_t temp = uint8_t(round(dutyCycle / 10));
    return uint8_t(round(dutyCycle / 10));
}


uint8_t Sensor(AlgoSensor & sensor)
{
    return sensor.getValue();
}
uint8_t Sensor(uint8_t port)
{
    switch(port)
    {
        case(1):
        {
            return Sensor1.getValue();
            break;
        }
        case(2):
        {
            return Sensor2.getValue();
            break;
        }
        default:
        {

        }
    }
}


uint8_t waitSensor(uint8_t port, int8_t value)
{
    uint8_t cvalue;
    if(value <= FALSE )
    {
        while(1)
        {
            cvalue = Sensor(port);

            if((cvalue == 0) && (value == FALSE))
            {
                break;
            }
            else if((cvalue != 0) && (value == TRUE))
            {
                break;
            }
        }
        delay(10);
        return cvalue;
    }
    else
    {
        while(1)
        {
            cvalue = Sensor(port);
            if(cvalue == value)
            {
                break; 
            }
            delay(1);
        }
        return cvalue;
    }
}
uint8_t waitSensor(uint8_t port, uint8_t min_value, uint8_t max_value)
{
    uint8_t cvalue;
    while(1)
    {
        cvalue = Sensor(port);
        if((cvalue >= min_value) && (cvalue <= max_value))
        {
           break; 
        }
        delay(1);
    }
    return cvalue;

}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
