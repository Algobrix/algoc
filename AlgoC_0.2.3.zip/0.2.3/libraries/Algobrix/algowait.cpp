/* Includes **************************************************************** */
#include "algowait.h"
#include "algobot.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
void controlWAIT(float period)
{
    uint32_t ms_period = period * 1000;
    delay(ms_period);
}

uint8_t controlWAIT(uint32_t line,uint32_t sequance,AlgoThread & cthread,float period)
{
	if(cthread.sequance != sequance)
	{
		return 0;
	}
	switch(cthread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			Serial.print("Wait on line [");
			Serial.print(line);
			Serial.print("] for [");
			Serial.print(period);
			Serial.println("] seconds");
			cthread.waitTimer = getSYSTIM();
			cthread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
			return OP_STATUS_RUNNING;
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			if(chk4TimeoutSYSTIM(cthread.waitTimer,period * 1000))
			{
				cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				cthread.sequance++;
				return OP_STATUS_COMPLETED;
			}
			return OP_STATUS_RUNNING;
			break;
		}
	}
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
