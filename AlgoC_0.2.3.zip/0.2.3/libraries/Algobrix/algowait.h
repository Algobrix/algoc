/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOWAIT_H
#define __ALGOWAIT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <algothread.h>

/* Exported constants ****************************************************** */

/* Exported macros ********************************************************* */
#define Wait(...)				controlWAIT(__LINE__,cThread.sequanceCnt++,cThread,__VA_ARGS__)

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */
void controlWAIT(float period);
uint8_t controlWAIT(uint32_t line,uint32_t sequance,AlgoThread & cthread,float period);

#endif 
/* ***************************** END OF FILE ******************************* */

