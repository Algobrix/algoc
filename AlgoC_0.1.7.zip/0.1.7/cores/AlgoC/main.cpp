/*
  main.cpp - Main loop for Arduino sketches
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <Arduino.h>
#include <systim.h>

#define R1 20000.0 // resistance of R1 (20K)
#define R2 10000.0 // resistance of R2 (10K)

// Declared weak in Arduino.h to allow user redefinitions.
int atexit(void (* /*func*/ )()) { return 0; }

// Weak empty variant initialization function.
// May be redefined by variant files.
void initVariant() __attribute__((weak));
void initVariant() { }

void chkALGOBOT() __attribute__((weak));
void chkALGOBOT() { }

void stopALGOBOT() __attribute__((weak));
void stopALGOBOT() { }

void initALGOBOT() __attribute__((weak));
void initALGOBOT() { }

void setup() __attribute__((weak));
void setup() { }

void loop() __attribute__((weak));
void loop() { }

void application() __attribute__((weak));
void application() { }
//void setupUSB() __attribute__((weak));
//void setupUSB() { }

uint16_t getBatteryVoltage(void);


uint8_t g_playState = 0x00;
uint32_t g_playTimer;


ISR(PCINT1_vect) 
{

    Serial.println("IRQ");
    if (!(PINC & (1 << PC0)))
    { 
        Serial.println("PB Low");
        if(g_ALGOBOT_INFO.state == ALGOBOT_STATE_RUN)
        {
            g_ALGOBOT_INFO.state = ALGOBOT_STATE_HALT;
            asm("jmp label_algobot_stop");
        }
        else
        {
            g_ALGOBOT_INFO.state = ALGOBOT_STATE_IDLE;
        }
    }
}

int main(void)
{
    init();

    initVariant();
    initALGOBOT();

    PCMSK1 |= 0x00; //PCINT8 PD5 C0
    PCIFR = 0b00000000; //Clear all flags
    PCICR |= 0x02; //Turn on port C PCIE2

#if defined(USBCON)
    USBDevice.attach();
#endif

    setup();
    Serial.begin(115200);
    uint8_t prevButtonState = digitalRead(PLAY_BUTTON_PIN);
    uint8_t buttonState = prevButtonState;
    uint8_t batteryError = 0x00;
    uint8_t batteryState = 0x00;
    uint32_t batteryTimer = getSYSTIM();
    g_playTimer = getSYSTIM();
    uint32_t voltage;
    for (;;) 
    {
        if(chk4TimeoutSYSTIM(g_playTimer,200) == SYSTIM_TIMEOUT)
        {
            Serial.println("Flip LED");
            g_playTimer = getSYSTIM();
            g_playState ^= 0x01;
            pinMode(PLAY_LED_PIN,OUTPUT);
            digitalWrite(PLAY_LED_PIN,g_playState);
        }
        voltage = getBatteryVoltage();
        if(chk4TimeoutSYSTIM(batteryTimer,200) == SYSTIM_TIMEOUT)
        {
            batteryTimer = getSYSTIM();
            if(voltage < 7000)
            {
                batteryState ^= 0x01;
                digitalWrite(POWER_LED_PIN,batteryState);
            }
            else
            {
                if(batteryState != 0x01)
                {
                    batteryState = 0x01;
                    digitalWrite(POWER_LED_PIN,batteryState);
                }

            }
        }
        buttonState = digitalRead(PLAY_BUTTON_PIN);
        if((voltage > 5000) && (buttonState == 0))
        {
            g_ALGOBOT_INFO.state = ALGOBOT_STATE_RUN;
            PCMSK1 |= 0x01;
            digitalWrite(PLAY_LED_PIN,0);
            digitalWrite(POWER_LED_PIN,0);
            application();
            loop();
            chkALGOBOT();
            if(g_ALGOBOT_INFO.state == ALGOBOT_STATE_RUN)
            {
                g_ALGOBOT_INFO.state = ALGOBOT_STATE_WAIT4STOP;
                g_playState = 0x01;
                pinMode(PLAY_LED_PIN,OUTPUT);
                digitalWrite(PLAY_LED_PIN,g_playState);
                while(g_ALGOBOT_INFO.state != ALGOBOT_STATE_IDLE)
                {

                }
            }
            asm("label_algobot_stop:");
                PCMSK1 &= ~(0x01);
                while(digitalRead(PLAY_BUTTON_PIN) == 0)
                {

                }
                stopALGOBOT();
        }
        else if(buttonState == 0)
        {
			Serial.print("Button press detected, but voltage is to low: ");
			Serial.println(voltage);
		}
			
        if (serialEventRun) serialEventRun();
    }
    return 0;
}

uint16_t getBatteryVoltage(void)
{
    uint32_t vout = 0.0;
    uint32_t vin = 0.0;
    pinMode(PLAY_BUTTON_PIN,OUTPUT);
    digitalWrite(PLAY_BUTTON_PIN,HIGH);
    delay(1);
    digitalWrite(PLAY_BUTTON_PIN,LOW);
    pinMode(PLAY_BUTTON_PIN,INPUT);
    vout = analogRead(POWER_METER_PIN);
    vout = (vout * 5000) / 1024;
    vin = vout / (R2 / (R1 + R2));
    return vin;
}
