/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOMOTOR_H
#define __ALGOMOTOR_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <algothread.h>
#include <system.h>

/* Exported constants ****************************************************** */
#define NUM_OF_MOTORS                                   3
#define MOTOR_MAX_POWER_LEVEL                           3
#define MOTOR_POWER_LEVEL_CNT                           10


#define A                                               MotorA
#define B                                               MotorB
#define C                                               MotorC


enum MOTOR_DIRECTION
{
    CW = 0x00,
	cw = 0x00,
    CCW = 0x01,
    ccw = 0x01,
};

enum ALGOMOTOR_STATE
{
    ALGOMOTOR_STATE_IDLE = 0x00,
    ALGOMOTOR_STATE_ON,
    ALGOMOTOR_STATE_OFF,
    ALGOMOTOR_STATE_TIMED_ON,
	ALGOMOTOR_STATE_ROTATION,
};

enum ALGOMOTOR_STATUS
{
	ALGOMOTOR_STATUS_INIT = 0x00,
	ALGOMOTOR_STATUS_RUNNING = 0x01,
	ALGOMOTOR_STATUS_COMPLETED = 0x00
};

enum ALGOMOTOR_PORT_ID
{
    MOTOR_A = 0x00,
    MOTOR_B,
    MOTOR_C,
};

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoMotor 
{
    private:
        uint8_t _directionPin;
        uint8_t _pwmPin;
    public:
		char id;
        uint8_t state;
		uint8_t prevState;
		uint8_t status;
        uint8_t outputState;
        uint8_t pwmValue;
        uint8_t direction;
		uint16_t rotCnt;
		float * rotationCounter;
		uint8_t rotationCounterFlag;
        uint32_t timer;
        uint32_t period;
        uint16_t * pOCR;
        uint16_t * pTCNT;
        uint8_t * pTIFR;
		


        AlgoMotor(uint8_t dirPin, uint8_t pwmPin,uint16_t * TCNT,uint8_t * TIFR,uint16_t * OCR,char id); 
        uint8_t run(uint32_t line,uint32_t sequance,AlgoThread & cthread, float time,uint8_t power,uint8_t dir,uint8_t mode);
		uint8_t rotation(uint32_t line,uint32_t sequance,AlgoThread & cthread, float rotation,uint8_t power,uint8_t dir,uint8_t mode);
        void changeSpeed(uint8_t pwm);
        void setPower(uint32_t power);
        void setRotationCnt(float rot);
		uint16_t getNumberOfRotations(void);
        void stop(void);
        uint32_t getRuntime(void);
};
/* Exported variables ****************************************************** */
extern AlgoMotor MotorA;
extern AlgoMotor MotorB;
extern AlgoMotor MotorC;

/* Exported functions ****************************************************** */
int isMotorCompleted(AlgoMotor & motor);

// uint8_t Move(System name,AlgoMotor & motor,float time,int power,int dir,int mode = BLOCKING);
void Move(System Name,char motorPort,float Seconds,int Power,int Direction,bool isBlocking);
uint8_t MoveAB(float time,uint8_t power,uint8_t dir);
uint8_t MoveAB(float time,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t MoveABC(float time,uint8_t power,uint8_t dir);
uint8_t MoveABC(float time,uint8_t power,uint8_t dir,uint8_t mode);

void Rotations(System Name,char motorPort,float Rotations,int Power,int Direction,bool isBlocking);
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir);
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir);
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir,uint8_t mode);

void StopMotor(System Name,char motorPort);
// void StopMotor(System Name,AlgoMotor & motor);
// void StopMotor(AlgoMotor & motor);

void StartCounting(System Name, char motorPort, float  & rotationCounter);
void StopCounting(System Name, char motorPort);

#endif 
/* ***************************** END OF FILE ******************************* */

