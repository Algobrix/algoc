/**
* @file        algobreak.h
* @author      semir-t
* @date        Juni 2023
* @version     1.0.0
*/

/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOBREAK_H
#define __ALGOBREAK_H
/* Includes **************************************************************** */

/* Module configuration **************************************************** */

/* Exported constants ****************************************************** */

/* Exported macros ********************************************************* */
#define BreakPoint(...)										controlBREAK(__LINE__,cThread.sequanceCnt++,cThread,##__VA_ARGS__)
/* #define breakPoint(...)										controlBREAK(__LINE__,cThread.sequanceCnt++,cThread,__VA_OPT__) */


/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */
uint8_t controlBREAK(uint32_t line,uint32_t sequance,AlgoThread & cthread,char breakChar = 0);

/* Exported functions ****************************************************** */

#endif 

