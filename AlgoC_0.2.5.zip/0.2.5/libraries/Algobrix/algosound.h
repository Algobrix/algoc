/* Define to prevent recursive inclusion *********************************** */
#ifndef __SOUNDPLAYER_H
#define __SOUNDPLAYER_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <softserial.h>
#include <algothread.h>

/* Exported constants ****************************************************** */
enum ALGOSOUND_STATE
{
    ALGOSOUND_STATE_IDLE = 0x00,
    ALGOSOUND_STATE_PLAYING,
};

enum ALGOSOUND_STATUS
{
	ALGOSOUND_STATUS_INIT = 0x00,
	ALGOSOUND_STATUS_RUNNING = 0x01,
	ALGOSOUND_STATUS_COMPLETED = 0x00
};
/* Exported macros ********************************************************* */
#define PlaySound(...)				controlSOUND(__LINE__,cThread.sequanceCnt++,cThread,__VA_ARGS__)

/* Exported types ********************************************************** */
class AlgoSound 
{
    private:
        SoftSerial soundSerial;
        String getTrackCommand(byte trackNumber);

    public:
        byte scriptRowId = 0;
        uint8_t status;
		uint8_t state;
        uint32_t timer;
        byte currentTrack = 0;
        AlgoSound(const byte txPin, const byte statePin);
        void play(byte trackId);
        void stop();
        void setVolume(int volumeLevel);
        void pause();
        uint8_t getStatus(void);
};


/* Exported variables ****************************************************** */
extern AlgoSound soundPlayer;

/* Exported functions ****************************************************** */
uint8_t controlSOUND(uint32_t line,uint32_t sequance,AlgoThread & cthread,uint8_t sound,uint8_t volume,uint8_t mode = 0);
void StopSound(void);
#endif 
/* ***************************** END OF FILE ******************************* */

