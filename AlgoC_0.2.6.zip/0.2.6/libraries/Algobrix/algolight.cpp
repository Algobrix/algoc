/* Includes **************************************************************** */
#include <algolight.h>
#include <algobot.h>

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
AlgoLight Light1(LED_A_PIN,1);
AlgoLight Light2(LED_B_PIN,2);

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoLight::AlgoLight(uint8_t pin,uint8_t id)
{
    this->_pin = pin;
	this->id = id;
    neoPixelLed =NeoPixel(1, this->_pin, NEO_GRB + NEO_KHZ800);
    neoPixelLed.begin();
}

void AlgoLight::setColor(uint8_t r,uint8_t g,uint8_t b)
{
    neoPixelLed.setPixelColor(0, neoPixelLed.Color(r, g, b));
    neoPixelLed.show();
}

void AlgoLight::stop(void)
{
    this->state = ALGOLED_LIGHT_STATE_OFF;
    setColor(0x00,0x00,0x00);
}

uint8_t Light(AlgoEngine engine,AlgoLight & light, float time,uint8_t power,uint32_t color, uint8_t mode)
{
	if(engine.cthread.sequance != engine.sequance)
	{
		return 0;
	}
	yield();
	switch(light.status)
	{
		case (ALGOLED_LIGHT_STATUS_INIT):
		{
			Serial.print("Control the LED [");
			Serial.print(light.id);
			Serial.print("] on line [");
			Serial.print(engine.line);
			Serial.print("]. Set color [");
			Serial.print(color,HEX);
			Serial.print("] with power [");
			Serial.print(power);
			Serial.print("] for period [");
			Serial.print(time);
			Serial.println("]");
			light.period = time * 1000; // time in seconds
			light.timer = getSYSTIM();
			uint8_t r =  ((color >> 16) & 0xff) * ((float)power/LIGHT_POWER_LEVEL_CNT);
			uint8_t g =  ((color >> 8) & 0xff) * ((float)power/LIGHT_POWER_LEVEL_CNT);
			uint8_t b =  ((color) & 0xff) * ((float)power/LIGHT_POWER_LEVEL_CNT);
			light.setColor(r,g,b);
			if((mode == OP_STATUS_BLOCKING) && (light.period != FOREVER))
			{
				light.state = ALGOLED_LIGHT_STATE_ON;
				light.timer = getSYSTIM();
				light.status = ALGOLED_LIGHT_STATUS_RUNNING;
				if(&engine.cthread == &threadAlgoC)
				{
					while(chk4TimeoutSYSTIM(light.timer,light.period) == SYSTIM_KEEP_ALIVE)
					{
						yield();
					}
					Serial.println("Stop light");
					light.stop();
					light.status = ALGOLED_LIGHT_STATUS_INIT;
					engine.cthread.sequance++;
					return 	ALGOLED_LIGHT_STATUS_COMPLETED;
				}
				else
				{
					return 	ALGOLED_LIGHT_STATUS_RUNNING;
				}
			}
			else
			{
				if(light.period == FOREVER)
				{
					light.state = ALGOLED_LIGHT_STATE_ON;
				}
				else
				{
					light.state = ALGOLED_LIGHT_STATE_TIMED_ON;
				}
				engine.cthread.sequance++;
				return 	ALGOLED_LIGHT_STATUS_COMPLETED;
			}
			break;
		}
		case (ALGOLED_LIGHT_STATUS_RUNNING):
		{
			if(chk4TimeoutSYSTIM(light.timer,light.period) == SYSTIM_TIMEOUT)
			{
				Serial.println("Stop light");
				light.stop();
				light.status = ALGOLED_LIGHT_STATUS_INIT;
				engine.cthread.sequance++;
				return 	ALGOLED_LIGHT_STATUS_COMPLETED;
			}
			return 	ALGOLED_LIGHT_STATUS_RUNNING;
			break;
		}
	}

}

uint8_t Light(AlgoEngine engine,uint8_t light, float time,uint8_t power,uint32_t color, uint8_t mode)
{
    switch(light)
    {
        case(1):
        {
			return Light(engine,Light1,time,power,color,mode);
            break;
        }
        case(2):
        {
			return Light(engine,Light2,time,power,color,mode);
            break;
        }
        default:
        {

        }
    }
}

int isLightCompleted(AlgoLight & light)
{
	yield();
	return (light.state == ALGOLED_LIGHT_STATE_OFF) ? true : false;
}

int isLightCompleted(uint8_t port)
{
	switch(port)
	{
		case(1):
		{
			return isLightCompleted(Light1);
			break;
		}
		case(2):
		{
			return isLightCompleted(Light2);
			break;
		}
		default:
		{

		}
	}
	return true;
}



#ifdef TEST
void Light(uint8_t port,float time,uint8_t power,uint32_t color)
{
    Light(port,time,power,color,OP_STATUS_BLOCKING);
}
void Light(uint8_t port,float time,uint8_t power,uint32_t color,uint8_t status)
{
    switch(port)
    {
        case(1):
        {
            Light(Light1,time,power,color,status);
            break;
        }
        case(2):
        {
            Light(Light2,time,power,color,status);
            break;
        }
        default:
        {

        }
    }
}

void Light12(float time,uint8_t power,uint32_t color)
{
    Light12(time,power,color,OP_STATUS_BLOCKING);
}
void Light12(float time,uint8_t power,uint32_t color,uint8_t status)
{
    if(status == OP_STATUS_BLOCKING)
    {
        Light(Light1,time,power,color,OP_STATUS_NONBLOCKING);
        Light(Light2,time,power,color,OP_STATUS_BLOCKING);
    }
    else
    {
        Light(Light1,time,power,color,status);
        Light(Light2,time,power,color,status);
    }
}


void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B)
{
    RGB(port,time,power,R,G,B,OP_STATUS_BLOCKING);
}
void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status)
{
    uint32_t color = R;
    color = (color << 8) | G;
    color = (color << 8) | B;
    Light(port,time,power,color,OP_STATUS_NONBLOCKING);
}
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B)
{
    uint32_t color = R;
    color = (color << 8) | G;
    color = (color << 8) | B;
    Light12(time,power,color,OP_STATUS_BLOCKING);
}
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status)
{
    uint32_t color = R;
    color = (color << 8) | G;
    color = (color << 8) | B;
    Light12(time,power,color,status);
}

#endif
void StopLight(AlgoEngine engine,uint8_t port)
{
	StopLight(port);
}

void StopLight(uint8_t port)
{
    switch(port)
    {
        case(1):
        {
            Light1.stop();
            break;
        }
        case(2):
        {
            Light2.stop();
            break;
        }
        default:
        {

        }
    }

}


/* Private functions ******************************************************* */


/* ***************************** END OF FILE ******************************* */
