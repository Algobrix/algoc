/* Includes **************************************************************** */
#include "algowait.h"
#include "algobot.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
uint8_t Wait(AlgoEngine engine,float period)
{
	if(engine.cthread.sequance != engine.sequance)
	{
		return 0;
	}
	yield();
	switch(engine.cthread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			Serial.print("Wait on line [");
			Serial.print(engine.line);
			Serial.print("] for [");
			Serial.print(period);
			Serial.println("] seconds");
			engine.cthread.waitTimer = getSYSTIM();
            engine.cthread.waitPeriod = period * 1000;
			if(&engine.cthread == &threadAlgoC)
			{
				while(chk4TimeoutSYSTIM(engine.cthread.waitTimer,engine.cthread.waitPeriod) == SYSTIM_KEEP_ALIVE)
				{
					yield();
				}
				engine.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				engine.cthread.sequance++;
				return OP_STATUS_COMPLETED;
			}
			else
			{
				engine.cthread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
				return OP_STATUS_RUNNING;
			}
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			if(chk4TimeoutSYSTIM(engine.cthread.waitTimer,engine.cthread.waitPeriod))
			{
				engine.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				engine.cthread.sequance++;
				return OP_STATUS_COMPLETED;
			}
			return OP_STATUS_RUNNING;
			break;
		}
	}
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
