/**
* @file        algoengine.h
* @author      semir-t
* @date        Juni 2023
* @version     1.0.0
*/

/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOENGINE_H
#define __ALGOENGINE_H
/* Includes **************************************************************** */
#include <Arduino.h>
#include "algothread.h"

/* Module configuration **************************************************** */

/* Exported constants ****************************************************** */

/* Exported macros ********************************************************* */

#define ALGOC_ENGINE				AlgoEngine(__LINE__,cThread.sequanceCnt++,cThread)

/* Exported types ********************************************************** */
class AlgoEngine 
{
    private:

    public:
		uint32_t line;
		uint32_t sequance;
		AlgoThread & cthread;
        AlgoEngine(uint32_t line,uint32_t sequance,AlgoThread & cthread); 
};

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */

#endif 

