/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOWAIT_H
#define __ALGOWAIT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <algothread.h>
#include <algoengine.h>

/* Exported constants ****************************************************** */

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */
uint8_t Wait(AlgoEngine engine,float period);

#endif 
/* ***************************** END OF FILE ******************************* */

