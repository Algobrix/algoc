/* Includes **************************************************************** */
#include <algolight.h>
#include <algobot.h>

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
AlgoLight Light1(LED_A_PIN,1);
AlgoLight Light2(LED_B_PIN,2);

const char c_color_name[6][8] = 
{
	"White",
	"Red",
	"Green",
	"Blue",
	"Purple",
	"Yellow",
};
const uint32_t c_color_value [6] = 
{
    LIGHT_COLOR_WHITE,
    LIGHT_COLOR_RED,
    LIGHT_COLOR_GREEN,
    LIGHT_COLOR_BLUE,
    LIGHT_COLOR_PURPLE,
    LIGHT_COLOR_YELLOW,
};






/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoLight::AlgoLight(uint8_t pin,uint8_t id)
{
    this->_pin = pin;
	this->id = id;
    neoPixelLed =NeoPixel(1, this->_pin, NEO_GRB + NEO_KHZ800);
    neoPixelLed.begin();
}

void AlgoLight::setColor(uint8_t r,uint8_t g,uint8_t b)
{
    neoPixelLed.setPixelColor(0, neoPixelLed.Color(r, g, b));
    neoPixelLed.show();
}

void AlgoLight::stop(void)
{
    this->state = ALGOLED_LIGHT_STATE_OFF;
    setColor(0x00,0x00,0x00);
}

uint8_t AlgoLight::run(uint32_t line,uint32_t sequance,AlgoThread & cthread,float time,uint8_t power,uint32_t color, uint8_t mode)
{
	if(cthread.sequance != sequance)
	{
		return 0;
	}
	yield();
	switch(this->status)
	{
		case (ALGOLED_LIGHT_STATUS_INIT):
		{
			Serial.print("Control the LED [");
			Serial.print(this->id);
			Serial.print("] on line [");
			Serial.print(line);
			Serial.print("]. Set color [");
			Serial.print(color,HEX);
			Serial.print("] with power [");
			Serial.print(power);
			Serial.print("] for period [");
			Serial.print(time);
			Serial.println("]");
			this->period = time * 1000; // time in seconds
			this->timer = getSYSTIM();
			uint8_t r =  ((color >> 16) & 0xff) * ((float)power/LIGHT_POWER_LEVEL_CNT);
			uint8_t g =  ((color >> 8) & 0xff) * ((float)power/LIGHT_POWER_LEVEL_CNT);
			uint8_t b =  ((color) & 0xff) * ((float)power/LIGHT_POWER_LEVEL_CNT);
			this->setColor(r,g,b);
			if((mode == OP_STATUS_BLOCKING) && (this->period != FOREVER))
			{
				this->state = ALGOLED_LIGHT_STATE_ON;
				this->timer = getSYSTIM();
				this->status = ALGOLED_LIGHT_STATUS_RUNNING;
				if(&cthread == &threadAlgoC)
				{
					while(chk4TimeoutSYSTIM(this->timer,this->period) == SYSTIM_KEEP_ALIVE)
					{
						yield();
					}
					Serial.println("Stop Light");
					this->stop();
					this->status = ALGOLED_LIGHT_STATUS_INIT;
					cthread.sequance++;
					return 	ALGOLED_LIGHT_STATUS_COMPLETED;
				}
				else
				{
					return 	ALGOLED_LIGHT_STATUS_RUNNING;
				}
			}
			else
			{
				if(this->period == FOREVER)
				{
					this->state = ALGOLED_LIGHT_STATE_ON;
				}
				else
				{
					this->state = ALGOLED_LIGHT_STATE_TIMED_ON;
				}
				cthread.sequance++;
				return 	ALGOLED_LIGHT_STATUS_COMPLETED;
			}
			break;
		}
		case (ALGOLED_LIGHT_STATUS_RUNNING):
		{
			if(chk4TimeoutSYSTIM(this->timer,this->period) == SYSTIM_TIMEOUT)
			{
				Serial.println("Stop light");
				this->stop();
				this->status = ALGOLED_LIGHT_STATUS_INIT;
				cthread.sequance++;
				return 	ALGOLED_LIGHT_STATUS_COMPLETED;
			}
			return 	ALGOLED_LIGHT_STATUS_RUNNING;
			break;
		}
	}
}

uint8_t Light(System Name,char lightPort, float Seconds,int Power,char * Color,bool blockingMode)
{
	uint8_t k = 0;
	for( k = 0; k < 8; k++ )
	{
		uint8_t res = strcmp(Color,c_color_name[k]);
		if(res == 0)
		{
			break;
		}
	}
	if(k == 8)
	{
		Serial.print("Specified color [");
		Serial.print(Color);
		Serial.print("] for the light on the line [");
		Serial.print(Name.line);
		Serial.print("Specified color for the light on the line [");
		Serial.println("] is invalide");
	}
	uint32_t color = c_color_value[k];
	switch(lightPort)
	{
		case('1'):
		{
			return Light1.run(Name.line,Name.sequance,Name.cthread,Seconds,Power,color,blockingMode);
			break;
		}
		case('2'):
		{
			return Light2.run(Name.line,Name.sequance,Name.cthread,Seconds,Power,color,blockingMode);
			break;
		}
	}
}


int isLightCompleted(AlgoLight & light)
{
	yield();
	return (light.state == ALGOLED_LIGHT_STATE_OFF) ? true : false;
}

int isLightCompleted(uint8_t port)
{
	switch(port)
	{
		case(1):
		{
			return isLightCompleted(Light1);
			break;
		}
		case(2):
		{
			return isLightCompleted(Light2);
			break;
		}
		default:
		{

		}
	}
	return true;
}



#ifdef TEST
void Light(uint8_t port,float time,uint8_t power,uint32_t color)
{
    Light(port,time,power,color,OP_STATUS_BLOCKING);
}
void Light(uint8_t port,float time,uint8_t power,uint32_t color,uint8_t status)
{
    switch(port)
    {
        case(1):
        {
            Light(Light1,time,power,color,status);
            break;
        }
        case(2):
        {
            Light(Light2,time,power,color,status);
            break;
        }
        default:
        {

        }
    }
}

void Light12(float time,uint8_t power,uint32_t color)
{
    Light12(time,power,color,OP_STATUS_BLOCKING);
}
void Light12(float time,uint8_t power,uint32_t color,uint8_t status)
{
    if(status == OP_STATUS_BLOCKING)
    {
        Light(Light1,time,power,color,OP_STATUS_NONBLOCKING);
        Light(Light2,time,power,color,OP_STATUS_BLOCKING);
    }
    else
    {
        Light(Light1,time,power,color,status);
        Light(Light2,time,power,color,status);
    }
}


void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B)
{
    RGB(port,time,power,R,G,B,OP_STATUS_BLOCKING);
}
void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status)
{
    uint32_t color = R;
    color = (color << 8) | G;
    color = (color << 8) | B;
    Light(port,time,power,color,OP_STATUS_NONBLOCKING);
}
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B)
{
    uint32_t color = R;
    color = (color << 8) | G;
    color = (color << 8) | B;
    Light12(time,power,color,OP_STATUS_BLOCKING);
}
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status)
{
    uint32_t color = R;
    color = (color << 8) | G;
    color = (color << 8) | B;
    Light12(time,power,color,status);
}

#endif
void StopLight(System Name, char lightPort)
{
    switch(lightPort)
    {
        case(1):
		case('1'):
        {
            Light1.stop();
            break;
        }
        case(2):
		case('2'):
        {
            Light2.stop();
            break;
        }
        default:
        {

        }
    }

}


/* Private functions ******************************************************* */


/* ***************************** END OF FILE ******************************* */
