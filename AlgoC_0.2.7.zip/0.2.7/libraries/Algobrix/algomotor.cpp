/* Includes **************************************************************** */
#include <Arduino.h>
#include "algomotor.h"
#include "algobot.h"
#include "systim.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* AlgoMotor MotorA(MOTOR_A_DIR, MOTOR_A_PWM); */
/* AlgoMotor MotorB(MOTOR_B_DIR, MOTOR_B_PWM); */
/* AlgoMotor MotorC(MOTOR_C_DIR, MOTOR_C_PWM); */


AlgoMotor MotorA(MOTOR_A_DIR, MOTOR_A_PWM,(uint16_t *) &TCNT3,(uint8_t *) &TIFR3,(uint16_t *)&OCR3A,'A');
AlgoMotor MotorB(MOTOR_B_DIR, MOTOR_B_PWM,(uint16_t *) &TCNT1,(uint8_t *) &TIFR1,(uint16_t *)&OCR1A,'B');
AlgoMotor MotorC(MOTOR_C_DIR, MOTOR_C_PWM,(uint16_t *) &TCNT4,(uint8_t *) &TIFR4,(uint16_t *)&OCR4A,'C');

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
AlgoMotor::AlgoMotor(uint8_t dirPin, uint8_t pwmPin,uint16_t * TCNT,uint8_t * TIFR,uint16_t * OCR,char id)
{
    _directionPin = dirPin;
    _pwmPin = pwmPin;
	this->id = id;
	pinMode(_directionPin,OUTPUT);
	pinMode(_pwmPin,OUTPUT);
    pOCR = OCR;
    pTCNT = TCNT;
    pTIFR = TIFR;
}

uint8_t AlgoMotor::run(uint32_t line,uint32_t sequance,AlgoThread & cthread, float time,uint8_t power,uint8_t dir,uint8_t mode)
{
	if(cthread.sequance != sequance)
	{
		return 0;
	}

	yield();
	switch(this->status)
	{
		case (ALGOMOTOR_STATUS_INIT):
		{
			Serial.print("Control the motor [");
			Serial.print(id);
			Serial.print("] on line [");
			Serial.print(line);
			Serial.print("]. Set direction [");
			Serial.print(dir);
			Serial.print("] with power [");
			Serial.print(power);
			Serial.print("] for period [");
			Serial.print(time);
			Serial.println("]");
			this->direction = dir;
			this->period = time * 1000;
			this->timer = getSYSTIM();
			this->rotCnt = 0;
			if(MotorA.rotationCounterFlag == 0)
			{
				setRotationCnt(50);
			}
			digitalWrite(_directionPin, dir);
			setPower(power);
			if(mode == OP_STATUS_BLOCKING)
			{
				this->state = ALGOMOTOR_STATE_ON;
				this->timer = getSYSTIM();
				if(&cthread == &threadAlgoC)
				{
					while(chk4TimeoutSYSTIM(this->timer,this->period) == SYSTIM_KEEP_ALIVE)
					{
						yield();
					}
					stop();
					this->status = ALGOMOTOR_STATUS_INIT;
					cthread.sequance++;
					return 	ALGOMOTOR_STATUS_COMPLETED;
				}
				else
				{
					this->status = ALGOMOTOR_STATUS_RUNNING;
					return 	ALGOMOTOR_STATUS_RUNNING;
				}

			}
			else
			{
				if(this->period == FOREVER)
				{
					this->state = ALGOMOTOR_STATE_ON;
				}
				else
				{
					this->state = ALGOMOTOR_STATE_TIMED_ON;
				}
				cthread.sequance++;
				return 	ALGOMOTOR_STATUS_COMPLETED;
			}
			break;
		}
		case (ALGOMOTOR_STATUS_RUNNING):
		{
			if(chk4TimeoutSYSTIM(this->timer,this->period) == SYSTIM_TIMEOUT)
			{
				Serial.println("Stop motor");
				stop();
				this->status = ALGOMOTOR_STATUS_INIT;
				cthread.sequance++;
				return 	ALGOMOTOR_STATUS_COMPLETED;
			}
			return 	ALGOMOTOR_STATUS_RUNNING;
			break;
		}
	}
}

uint16_t AlgoMotor::getNumberOfRotations(void)
{
	return rotCnt;
}

uint8_t AlgoMotor::rotation(uint32_t line,uint32_t sequance,AlgoThread & cthread, float rotation,uint8_t power,uint8_t dir,uint8_t mode)
{
	if(cthread.sequance != sequance)
	{
		return 0;
	}

	yield();
	switch(this->status)
	{
		case (ALGOMOTOR_STATUS_INIT):
		{
			Serial.print("Control the motor [");
			Serial.print(id);
			Serial.print("] on line [");
			Serial.print(line);
			Serial.print("]. Set direction [");
			Serial.print(dir);
			Serial.print("] with power [");
			Serial.print(power);
			Serial.print("] for number of rotations [");
			Serial.print(rotation);
			Serial.println("]");
			this->direction = dir;
			this->period = FOREVER;
			this->timer = getSYSTIM();
			setRotationCnt(rotation);
			digitalWrite(_directionPin, dir);
			setPower(power);
			if(mode == OP_STATUS_BLOCKING)
			{
				this->state = ALGOMOTOR_STATE_ROTATION;
				this->timer = getSYSTIM();
				if(&cthread == &threadAlgoC)
				{
					while(this->state == ALGOMOTOR_STATE_ON)
					{
						yield();
					}
					stop();
					this->status = ALGOMOTOR_STATUS_INIT;
					cthread.sequance++;
					return 	ALGOMOTOR_STATUS_COMPLETED;
				}
				else
				{
					this->status = ALGOMOTOR_STATUS_RUNNING;
					return 	ALGOMOTOR_STATUS_RUNNING;
				}

			}
			else
			{
				this->state = ALGOMOTOR_STATE_ROTATION;
				cthread.sequance++;
				return 	ALGOMOTOR_STATUS_COMPLETED;
			}
			break;
		}
		case (ALGOMOTOR_STATUS_RUNNING):
		{
			if(chk4TimeoutSYSTIM(this->timer,this->period) == SYSTIM_TIMEOUT)
			{
				Serial.println("Stop motor");
				stop();
				this->status = ALGOMOTOR_STATUS_INIT;
				cthread.sequance++;
				return 	ALGOMOTOR_STATUS_COMPLETED;
			}
			return 	ALGOMOTOR_STATUS_RUNNING;
			break;
		}
	}
}

void AlgoMotor::changeSpeed(uint8_t pwm) 
{
    pwmValue = pwm;
    switch(_pwmPin) 
    {
        case (MOTOR_A_PWM): 
        {
            switch (pwmValue) 
            {
                case 0:
                case 255: 
                {
                    outputState = 0; 
                    digitalWrite(_pwmPin, pwmValue);
                    TIMSK2 = (TIMSK2 & B11111101) | B00000000; // Disable Compare A Interrupt
                    break;
                }
                default: 
                {
                    OCR2A = pwmValue;
                    TIMSK2 = (TIMSK2 & B11111101) | B00000010; // Enable Compare A Interrupt
                    break;
                }
            }
            break;
        }
        case (MOTOR_B_PWM): 
        {
            switch(pwmValue) 
            {
                case 0:
                case 255: 
                {
                    outputState = 0; 
                    digitalWrite(_pwmPin, pwmValue);
                    TIMSK2 = (TIMSK2 & B11111011) | B00000000; // Disable Compare B Interrupt
                    break;
                }
                default: 
                {
                    OCR2B = pwmValue;
                    TIMSK2 = (TIMSK2 & B11111011) | B00000100; // Enable Compare B Interrupt
                    break;
                }
            }
            break;
        }
        default: 
        {
            analogWrite(_pwmPin, pwmValue);
            break;
        }
    }
}

void AlgoMotor::stop(void) 
{
	if(state != ALGOMOTOR_STATE_IDLE)
	{
		changeSpeed(0);
	}
    state = ALGOMOTOR_STATE_IDLE;
}
uint32_t AlgoMotor::getRuntime(void)
{
    return getElapsedTimeSYSTIM(timer);		
}

void AlgoMotor::setPower(uint32_t power)
{
    uint32_t value = (power * 255)/MOTOR_POWER_LEVEL_CNT;
    changeSpeed(value);
}

void AlgoMotor::setRotationCnt(float rot)
{
    uint16_t pulseCnt = rot * 2 * 360;
    *pOCR = pulseCnt;
    *pTCNT = 0;
    *pTIFR = 0;
}


uint8_t Move(System Name,char motorPort,float Seconds,int Power,int Direction,bool blockingMode)
{
	switch(motorPort)
	{
		case('A'):
		{
			return MotorA.run(Name.line,Name.sequance,Name.cthread,Seconds,Power,Direction,blockingMode);
			break;
		}
		case('B'):
		{
			return MotorB.run(Name.line,Name.sequance,Name.cthread,Seconds,Power,Direction,blockingMode);
			break;
		}
		case('C'):
		{
			return MotorC.run(Name.line,Name.sequance,Name.cthread,Seconds,Power,Direction,blockingMode);
			break;
		}

	}
}


int isMotorCompleted(AlgoMotor & motor)
{
	yield();
	return (motor.state == ALGOMOTOR_STATE_OFF) ? true : false;
}


#ifdef TEST
uint8_t MoveAB(float time,uint8_t power,uint8_t dir)
{
    Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
    Move(MotorB,time,power,dir,OP_STATUS_BLOCKING);
}
uint8_t MoveAB(float time,uint8_t power,uint8_t dir, uint8_t mode)
{
    if(mode == OP_STATUS_BLOCKING)
    {
        Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
        Move(MotorB,time,power,dir,OP_STATUS_BLOCKING);
    }
    else
    {
        Move(MotorA,time,power,dir,mode);
        Move(MotorB,time,power,dir,mode);
    }
}
uint8_t MoveABC(float time,uint8_t power,uint8_t dir)
{
    Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
    Move(MotorB,time,power,dir,OP_STATUS_NONBLOCKING);
    Move(MotorC,time,power,dir,OP_STATUS_BLOCKING);
}
uint8_t MoveABC(float time,uint8_t power,uint8_t dir,uint8_t mode)
{
    if(mode == OP_STATUS_BLOCKING)
    {
        Move(MotorA,time,power,dir,OP_STATUS_NONBLOCKING);
        Move(MotorB,time,power,dir,OP_STATUS_NONBLOCKING);
        Move(MotorC,time,power,dir,OP_STATUS_BLOCKING);
    }
    else
    {
        Move(MotorA,time,power,dir,mode);
        Move(MotorB,time,power,dir,mode);
        Move(MotorC,time,power,dir,mode);
    }

}
#endif



uint8_t Rotations(System Name,char motorPort,float Rotations,int Power,int Direction,bool blockingMode)
{
	switch(motorPort)
	{
		case('A'):
		{
			return MotorA.rotation(Name.line,Name.sequance,Name.cthread,Rotations,Power,Direction,blockingMode);
			break;
		}
		case('B'):
		{
			return MotorB.rotation(Name.line,Name.sequance,Name.cthread,Rotations,Power,Direction,blockingMode);
			break;
		}
		case('C'):
		{
			return MotorC.rotation(Name.line,Name.sequance,Name.cthread,Rotations,Power,Direction,blockingMode);
			break;
		}
	}
}


#ifdef TEST
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,BLOCKING); 
}
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir,uint8_t mode)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,mode); 
}
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,NONBLOCKING); 
    Rotations(C,rot,power,dir,BLOCKING); 

}
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir,uint8_t mode)
{
    Rotations(A,rot,power,dir,NONBLOCKING); 
    Rotations(B,rot,power,dir,NONBLOCKING); 
    Rotations(C,rot,power,dir,mode); 
}

#endif

void StopMotor(System Name,char motorPort)
{
	switch(motorPort)
	{
		case('A'):
		{
			MotorA.stop();
			break;
		}
		case('B'):
		{
			MotorB.stop();
			break;
		}
		case('C'):
		{
			MotorC.stop();
			break;
		}
	}
}


float NumberOfRotations(System Name,AlgoMotor & motor)
{
	float cnt = motor.rotCnt;
	cnt = cnt / 720.;
	return cnt;
}
void StartCounting(System Name, char motorPort, float & rotationCounter)
{
	if(Name.cthread.sequance != Name.sequance)
	{
		return;
	}

	switch(motorPort)
	{
		case('A'):
		{
			MotorA.rotCnt = 0;
			MotorA.rotationCounter = &rotationCounter;
			MotorA.rotationCounterFlag = 1;
			*MotorA.pOCR = 2;
			*MotorA.pTCNT = 0;
			*MotorA.pTIFR = 0;

			break;
		}
		case('B'):
		{
			MotorB.rotCnt = 0;
			MotorB.rotationCounter = &rotationCounter;
			MotorB.rotationCounterFlag = 1;
			*MotorB.pOCR = 2;
			*MotorB.pTCNT = 0;
			*MotorB.pTIFR = 0;
			break;
		}
		case('C'):
		{
			MotorC.rotCnt = 0;
			MotorC.rotationCounter = &rotationCounter;
			MotorC.rotationCounterFlag = 1;
			*MotorC.pOCR = 2;
			*MotorC.pTCNT = 0;
			*MotorC.pTIFR = 0;
			break;
		}
	}
	Name.cthread.sequance++;
}

void StopCounting(System Name, char motorPort)
{

	if(Name.cthread.sequance != Name.sequance)
	{
		return;
	}

	switch(motorPort)
	{
		case('A'):
		{
			MotorA.rotationCounterFlag = 0;
			*MotorA.rotationCounter = (float) MotorA.rotCnt / 360;
			break;
		}
		case('B'):
		{
			MotorB.rotationCounterFlag = 0;
			*MotorB.rotationCounter = (float )MotorB.rotCnt / 360;
			break;
		}
		case('C'):
		{
			MotorC.rotationCounterFlag = 0;
			*MotorC.rotationCounter = (float )MotorC.rotCnt / 360;
			break;
		}
	}
	Name.cthread.sequance++;
}


/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
