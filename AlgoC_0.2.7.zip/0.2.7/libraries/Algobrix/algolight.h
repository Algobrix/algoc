/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOLED_LIGHT_H
#define __ALGOLED_LIGHT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <system.h>
#include <neopixel.h>
#include <algothread.h>
#include <algobot.h>

/* Exported constants ****************************************************** */
#define LIGHT_POWER_LEVEL_CNT                           10

enum ALGOLED_LIGHT_STATE
{
	ALGOLED_LIGHT_STATE_OFF = 0x00,
	ALGOLED_LIGHT_STATE_ON,
    ALGOLED_LIGHT_STATE_TIMED_ON,
};

enum ALGOLED_THREAD_STATE
{
	ALGOLED_THREAD_STATE_INIT = 0x00,
	ALGOLED_THREAD_STATE_RUN,
};

enum ALGOLED_LIGHT_COLOR
{
    LIGHT_COLOR_WHITE = 0xffffff,
    LIGHT_COLOR_RED = 0xff0000,
    LIGHT_COLOR_GREEN = 0x00ff00,
    LIGHT_COLOR_BLUE = 0x0000ff,
    LIGHT_COLOR_PURPLE = 0xff00ff,
    LIGHT_COLOR_YELLOW = 0x00ffff,
};



enum ALGOLED_LIGHT_STATUS
{
	ALGOLED_LIGHT_STATUS_INIT = 0x00,
	ALGOLED_LIGHT_STATUS_RUNNING = 0x01,
	ALGOLED_LIGHT_STATUS_COMPLETED = 0x00
};
/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoLight
{
    private:
        NeoPixel neoPixelLed;
        uint8_t _pin;
    public:
		uint8_t id;
        uint8_t state;
        uint32_t period;
        uint32_t timer;
		uint8_t threadState;
		uint8_t status;
		AlgoLight(uint8_t pin,uint8_t id);

        void setColor(uint8_t r,uint8_t g,uint8_t b);
        void stop(void);
        uint8_t run(uint32_t line,uint32_t sequance,AlgoThread & cthread,float time,uint8_t power,uint32_t color, uint8_t mode);
};

/* Exported variables ****************************************************** */
extern AlgoLight Light1;
extern AlgoLight Light2;


/* Exported functions ****************************************************** */
uint8_t Light(System Name,char lightPort, float Seconds,int Power,char * Color,bool blockingMode = true);

int isLightCompleted(AlgoLight & light);
int isLightCompleted(uint8_t port);
void Light12(float time,uint8_t power,uint32_t color);
void Light12(float time,uint8_t power,uint32_t color,uint8_t status);
void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B);
void RGB(uint8_t port,float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status);
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B);
void RGB12(float time,uint8_t power,uint8_t R,uint8_t G,uint8_t B,uint8_t status);

void StopLight(System Name, char lightPort);
#endif 
/* ***************************** END OF FILE ******************************* */


