/* Includes **************************************************************** */
#include "algowait.h"
#include "algobot.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
uint8_t Wait(System Name,float period)
{
	if(Name.cthread.sequance != Name.sequance)
	{
		return 0;
	}
	yield();
	switch(Name.cthread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			Serial.print("Wait on line [");
			Serial.print(Name.line);
			Serial.print("] for [");
			Serial.print(period);
			Serial.println("] seconds");
			Name.cthread.waitTimer = getSYSTIM();
            Name.cthread.waitPeriod = period * 1000;
			if(&Name.cthread == &threadAlgoC)
			{
				while(chk4TimeoutSYSTIM(Name.cthread.waitTimer,Name.cthread.waitPeriod) == SYSTIM_KEEP_ALIVE)
				{
					yield();
				}
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				return OP_STATUS_COMPLETED;
			}
			else
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
				return OP_STATUS_RUNNING;
			}
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			if(chk4TimeoutSYSTIM(Name.cthread.waitTimer,Name.cthread.waitPeriod))
			{
				Name.cthread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				Name.cthread.sequance++;
				return OP_STATUS_COMPLETED;
			}
			return OP_STATUS_RUNNING;
			break;
		}
	}
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
