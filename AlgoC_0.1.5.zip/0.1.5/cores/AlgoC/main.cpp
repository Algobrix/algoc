/*
  main.cpp - Main loop for Arduino sketches
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <Arduino.h>
#include <systim.h>

#define R1 20000.0 // resistance of R1 (20K)
#define R2 10000.0 // resistance of R2 (10K)

// Declared weak in Arduino.h to allow user redefinitions.
int atexit(void (* /*func*/ )()) { return 0; }

// Weak empty variant initialization function.
// May be redefined by variant files.
void initVariant() __attribute__((weak));
void initVariant() { }

void chkALGOBOT() __attribute__((weak));
void chkALGOBOT() { }

void initALGOBOT() __attribute__((weak));
void initALGOBOT() { }

void setup() __attribute__((weak));
void setup() { }

void loop() __attribute__((weak));
void loop() { }

void application() __attribute__((weak));
void application() { }
//void setupUSB() __attribute__((weak));
//void setupUSB() { }

uint16_t getBatteryVoltage(void);
int main(void)
{
    init();

    initVariant();
    initALGOBOT();

#if defined(USBCON)
    USBDevice.attach();
#endif

    setup();
    Serial.begin(115200);
    uint8_t prevButtonState = digitalRead(PLAY_BUTTON_PIN);
    uint8_t buttonState = prevButtonState;
    uint8_t playState = 0x00;
    uint32_t playTimer = getSYSTIM();
    uint8_t batteryError = 0x00;
    uint8_t batteryState = 0x00;
    uint32_t batteryTimer = getSYSTIM();
    uint32_t voltage;
    for (;;) 
    {
        if(chk4TimeoutSYSTIM(playTimer,200) == SYSTIM_TIMEOUT)
        {
            playTimer = getSYSTIM();
            playState ^= 0x01;
            digitalWrite(PLAY_LED_PIN,playState);
        }
        voltage = getBatteryVoltage();
        if(chk4TimeoutSYSTIM(batteryTimer,200) == SYSTIM_TIMEOUT)
        {
            batteryTimer = getSYSTIM();
            if(voltage < 7000)
            {
                batteryState ^= 0x01;
                digitalWrite(POWER_LED_PIN,batteryState);
            }
            else
            {
                if(batteryState != 0x01)
                {
                    batteryState = 0x01;
                    digitalWrite(POWER_LED_PIN,batteryState);
                }

            }
            Serial.print("Voltage: ");
            Serial.println(voltage);
        }
        buttonState = digitalRead(PLAY_BUTTON_PIN);
        if((voltage > 5000) && (buttonState == 0))
        {
            digitalWrite(PLAY_LED_PIN,0);
            digitalWrite(POWER_LED_PIN,0);
            application();
            loop();
            chkALGOBOT();
        }
        else if(buttonState == 0)
        {
			Serial.print("Button press detected, but voltage is to low: ");
			Serial.println(voltage);
		}
			
        if (serialEventRun) serialEventRun();
    }
    return 0;
}

uint16_t getBatteryVoltage(void)
{
    uint32_t vout = 0.0;
    uint32_t vin = 0.0;
    pinMode(PLAY_BUTTON_PIN,OUTPUT);
    digitalWrite(PLAY_BUTTON_PIN,HIGH);
    delay(1);
    digitalWrite(PLAY_BUTTON_PIN,LOW);
    pinMode(PLAY_BUTTON_PIN,INPUT);
    vout = analogRead(POWER_METER_PIN);
    vout = (vout * 5000) / 1024;
    vin = vout / (R2 / (R1 + R2));
    return vin;
}
