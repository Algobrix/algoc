/* Define to prevent recursive inclusion *********************************** */
#ifndef __SOUNDPLAYER_H
#define __SOUNDPLAYER_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <softserial.h>

/* Exported constants ****************************************************** */
enum ALGOSOUND_STATUS
{
    ALGOSOUND_STATUS_IDLE = 0x00,
    ALGOSOUND_STATUS_PLAYING,
};
/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoSound 
{
    private:
        SoftSerial soundSerial;
        uint32_t timer;
        uint8_t status;
        byte currentTrack = 0;
        String getTrackCommand(byte trackNumber);

    public:
        byte scriptRowId = 0;
        AlgoSound(const byte txPin, const byte statePin);
        void play(byte trackId);
        void stop();
        void setVolume(int volumeLevel);
        uint8_t getStatus(void);
};


/* Exported variables ****************************************************** */
extern AlgoSound soundPlayer;

/* Exported functions ****************************************************** */
void PlaySound(uint8_t sound,uint8_t volume);
void PlaySound(uint8_t sound,uint8_t volume,uint8_t status);
void StopSound(void);
#endif 
/* ***************************** END OF FILE ******************************* */

