/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOMOTOR_H
#define __ALGOMOTOR_H

/* Includes **************************************************************** */
#include <Arduino.h>

/* Exported constants ****************************************************** */
#define NUM_OF_MOTORS                                   3
#define MOTOR_MAX_POWER_LEVEL                           3
#define MOTOR_POWER_LEVEL_CNT                           10


#define A                                               MotorA
#define B                                               MotorB
#define C                                               MotorC

enum MOTOR_DIRECTION
{
    CW = 0x00,
    CCW,
};

enum ALGOMOTOR_STATE
{
    ALGOMOTOR_STATE_IDLE = 0x00,
    ALGOMOTOR_STATE_ON,
    ALGOMOTOR_STATE_OFF,
    ALGOMOTOR_STATE_TIMED_ON,
};

enum ALGOMOTOR_PORT_ID
{
    MOTOR_A = 0x00,
    MOTOR_B,
    MOTOR_C,
};

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */
class AlgoMotor 
{
    private:
        uint8_t _directionPin;
        uint8_t _pwmPin;
    public:
        uint8_t state;
        uint8_t outputState;
        uint8_t pwmValue;
        uint8_t direction;
        uint32_t timer;
        uint32_t period;
        uint16_t * pOCR;
        uint16_t * pTCNT;
        uint8_t * pTIFR;

        AlgoMotor(uint8_t dirPin, uint8_t pwmPin,uint16_t * TCNT,uint8_t * TIFR,uint16_t * OCR); 
        void run(float time,uint8_t power,uint8_t dir,uint8_t mode);
        void changeSpeed(uint8_t pwm);
        void setPower(uint32_t power);
        void setRotationCnt(float rot);
        void stop(void);
        uint32_t getRuntime(void);
};
/* Exported variables ****************************************************** */
extern AlgoMotor MotorA;
extern AlgoMotor MotorB;
extern AlgoMotor MotorC;

/* Exported functions ****************************************************** */
uint8_t Move(uint8_t port,float time,uint8_t power,uint8_t dir);
uint8_t Move(uint8_t port,float time,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t Move(AlgoMotor & motor,float time,uint8_t power,uint8_t dir);
uint8_t Move(AlgoMotor & motor,float time,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t MoveAB(float time,uint8_t power,uint8_t dir);
uint8_t MoveAB(float time,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t MoveABC(float time,uint8_t power,uint8_t dir);
uint8_t MoveABC(float time,uint8_t power,uint8_t dir,uint8_t mode);

/* uint8_t Rotations(uint8_t portId,float time,uint8_t power); */
/* uint8_t Rotations(uint8_t portId,float time,uint8_t power,uint8_t mode); */
uint8_t Rotations(AlgoMotor & motor,float rot,uint8_t power,uint8_t dir);
uint8_t Rotations(AlgoMotor & motor,float rot,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir);
uint8_t RotationsAB(float rot,uint8_t power,uint8_t dir,uint8_t mode);
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir);
uint8_t RotationsABC(float rot,uint8_t power,uint8_t dir,uint8_t mode);

void StopMotor(AlgoMotor & motor);


#endif 
/* ***************************** END OF FILE ******************************* */

