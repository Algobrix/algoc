/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOBOT_H
#define __ALGOBOT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include "systim.h"
#include <algolight.h>
#include <algomotor.h>
#include <algobot.h>
#include <algosound.h>
#include <algowait.h>
#include <algosensor.h>

/* Exported constants ****************************************************** */
#define FOREVER                                     0

enum OP_STATUS
{
    OP_STATUS_BLOCKING = 0x00,
    OP_STATUS_NONBLOCKING = 0x01,
    BLOCKING = 0x00,
    NONBLOCKING = 0x01,
};

enum BOOL
{
    FALSE = -1,
    TRUE = -2,
};

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */
void initALGOBOT(void);

#endif 
/* ***************************** END OF FILE ******************************* */

