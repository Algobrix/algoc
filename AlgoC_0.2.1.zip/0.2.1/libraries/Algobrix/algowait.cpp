/* Includes **************************************************************** */
#include "algowait.h"
#include "algobot.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */

/* Private function prototypes ********************************************* */

/* Exported functions ****************************************************** */
void Wait(float period)
{
    uint32_t ms_period = period * 1000;
    delay(ms_period);
}

uint8_t Wait(AlgoThread & thread,float period)
{
	switch(thread.waitState)
	{
		case(ALGOTHREAD_WAIT_STATE_INIT):
		{
			thread.waitTimer = getSYSTIM();
			thread.waitState = ALGOTHREAD_WAIT_STATE_RUN;
			return OP_STATUS_RUNNING;
			break;
		}
		case(ALGOTHREAD_WAIT_STATE_RUN):
		{
			if(chk4TimeoutSYSTIM(thread.waitTimer,period * 1000))
			{
				thread.waitState = ALGOTHREAD_WAIT_STATE_INIT;
				return OP_STATUS_COMPLETED;
			}
			return OP_STATUS_RUNNING;
			break;
		}
	}
}

/* Private functions ******************************************************* */

/* ***************************** END OF FILE ******************************* */
