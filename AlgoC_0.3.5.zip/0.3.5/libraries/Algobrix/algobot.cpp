/* Includes **************************************************************** */
#include "algobot.h"
#include "compileTime.h"

/* Private constants ******************************************************* */


/* Private macros ********************************************************** */

/* Private types *********************************************************** */

/* Private variables ******************************************************* */
volatile ALGOBOT_INFO g_ALGOBOT_INFO;
const uint32_t c_current_build_time = __TIME_UNIX__;

/* Private function prototypes ********************************************* */
static void initMOTOR(void);
static void initENCODER(void);
static void initUI(void);
static void initLIGHT(void);
static void chkMOTOR(void);
static void chkLIGHT(void);
/* static void chkMOTOR(void); */

/* Exported functions ****************************************************** */
void initALGOBOT(void)
{
    initMOTOR();
    initENCODER();
    initLIGHT();
    initUI();
	initTHREADS();

    uint32_t timer = getSYSTIM();
    uint8_t state = 0;
    g_ALGOBOT_INFO.state = ALGOBOT_STATE_IDLE;
    while(0)
    {
        if(chk4TimeoutSYSTIM(timer,200) == SYSTIM_TIMEOUT)
        {
            timer = getSYSTIM();
            state ^= 0x01;
            digitalWrite(PLAY_LED_PIN,state);
        }
        if(digitalRead(PLAY_BUTTON_PIN) == 0)
        {
            digitalWrite(PLAY_LED_PIN,0);
            break;
        }
    }
}

void chkALGOBOT(void)
{
	chkTHREADS();
    chkMOTOR();
    chkLIGHT();
}

void stopALGOBOT(void)
{
	g_ALGOBOT_INFO.state = ALGOBOT_STATE_IDLE;
	AlgoThread & cThread = threadAlgoC;
    stopMotor(ALGOC,'A');
    stopMotor(ALGOC,'B');
    stopMotor(ALGOC,'C');
    stopLight(ALGOC,1);
    stopLight(ALGOC,2);
    stopSound(ALGOC);
	resetAllThreads();
}

void wait4CompletionALGOBOT(void)
{
	while((A.status != ALGOMOTOR_STATUS_INIT) && (B.status != ALGOMOTOR_STATUS_INIT) && (C.status != ALGOMOTOR_STATUS_INIT))
	{

	}
}

uint8_t yield(void)
{
    if(g_ALGOBOT_INFO.state == ALGOBOT_STATE_HALT)
    {
        return 1;
    }
    if(g_ALGOBOT_INFO.state == ALGOBOT_STATE_RUN)
	{
		if(chk4TimeoutSYSTIM(g_playTimer,200) == SYSTIM_TIMEOUT)
		{
			g_playTimer = getSYSTIM();
			g_playState ^= 0x01;
			pinMode(PLAY_LED_PIN,OUTPUT);
			digitalWrite(PLAY_LED_PIN,g_playState);
		}
	}
    chkALGOBOT();
	if(Serial.available())
	{
		char control = Serial.read();
		switch(control)
		{
			case('p'):
			case('P'):
			{
				break;
			}
			case('s'):
			case('S'):
			{
				resetAllThreads();
				stopALGOBOT();
				break;
			}

		}

	}

	return 0;
}

/* Private functions ******************************************************* */
void initMOTOR(void)
{
  // Initialize TIMER2 for PWM of motors A and B.
  TCNT2 = 0;
  TIFR2 = 0;
  TCCR2A = 0;
  TCCR2B = (TCCR2B & B11111100) | B00000011;  // Clock I/O with prescaler of 64.
  OCR2A = 0;                                  // Compare Value A - for motor A
  OCR2B = 0;                                  // Compare Value B - for motor B
  TIMSK2 = (TIMSK2 & B11111111) | B00000000;  // Timer2 disabled by default - enabled when used for enabling the motors.
}

void initENCODER(void)
{

  pinMode(MOTOR_A_ENCODER, INPUT);
  pinMode(MOTOR_B_ENCODER, INPUT);
  pinMode(MOTOR_C_ENCODER, INPUT);
  // When Changing Bits -> Use mask so that only the significant bits are affected

  // MOTOR A - Initialize Timer3
  TCNT3 = 0;                                  // Timer/Counter Register. The actual timer value is stored here.
  TIFR3 = 0;                                  // Timer/Counter Interrupt Flag Register
  TCCR3A = 0;                                 // PWM Mode is OFF.
  TCCR3B = (TCCR3B & B11110001) | B00001110;  // External clock source on T3 pin. Clock on falling edge. + CTC = Clear Timer (on) Compare Mode.
  OCR3A = 0;                                  // The Compare value of Timer4 --> If TCNT4 == OCR3A --> Call Interrupt.
  TIMSK3 = (TIMSK3 & B11111101) | B00000010;  // Enable Timer3 compare interrupt - ALWAYS ENABLED.
  
  // MOTOR B - Initialize Timer1
  TCNT1 = 0;
  TIFR1 = 0;
  TCCR1A = 0;
  TCCR1B = (TCCR1B & B11110001) | B00001110;
  OCR1A = 0;
  TIMSK1 = (TIMSK1 & B11111101) | B00000010;
  
  // MOTOR C - Initialize Timer4
  TCNT4 = 0;
  TIFR4 = 0;
  TCCR4A = 0;
  TCCR4B = (TCCR4B & B11110001) | B00001110;
  OCR4A = 0;
  TIMSK4 = (TIMSK4 & B11111101) | B00000010;

}

void chkMOTOR(void)
{
    if(MotorA.state == ALGOMOTOR_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(MotorA.timer,MotorA.period) == SYSTIM_TIMEOUT)
        {
            MotorA.stop();
        }
    }
    if(MotorB.state == ALGOMOTOR_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(MotorB.timer,MotorB.period) == SYSTIM_TIMEOUT)
        {
            MotorB.stop();
        }
    }
    if(MotorC.state == ALGOMOTOR_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(MotorC.timer,MotorC.period) == SYSTIM_TIMEOUT)
        {
            MotorC.stop();
        }
    }
}

void initLIGHT(void)
{
    Light1.stop();
    Light2.stop();
}
void chkLIGHT(void)
{
    if(Light1.state == ALGOLED_LIGHT_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(Light1.timer,Light1.period) == SYSTIM_TIMEOUT)
        {
            Light1.stop();
        }
    }
    if(Light2.state == ALGOLED_LIGHT_STATE_TIMED_ON)
    {
        if(chk4TimeoutSYSTIM(Light2.timer,Light2.period) == SYSTIM_TIMEOUT)
        {
            Light2.stop();
        }
    }
}

void initUI(void)
{
	pinMode(PLAY_LED_PIN,OUTPUT);
    pinMode(PLAY_BUTTON_PIN,INPUT);
	/* pinMode(POWER_LED_PIN,OUTPUT); */
}

ISR(TIMER2_COMPA_vect) 
{
  noInterrupts();
  if(MotorA.outputState) 
  {
    digitalWrite(MOTOR_A_PWM, LOW);
    OCR2A = 0;
    MotorA.outputState = 0;
  } 
  else 
  {
    digitalWrite(MOTOR_A_PWM, HIGH);
    OCR2A = MotorA.pwmValue;
    MotorA.outputState = 1;
  }
  interrupts();
}

ISR(TIMER2_COMPB_vect) 
{
  noInterrupts();
  if(MotorB.outputState) 
  {
    digitalWrite(MOTOR_B_PWM, LOW);
    OCR2B = 0;
    MotorB.outputState = 0;
  } 
  else 
  {
    digitalWrite(MOTOR_B_PWM, HIGH);
    OCR2B = MotorB.pwmValue;
    MotorB.outputState = 1;
  }
  interrupts();
}

ISR(TIMER3_COMPA_vect) 
{
	noInterrupts();

	if(MotorA.state == ALGOMOTOR_STATE_ROTATION)
	{
		MotorA.stop();
	}
	else
	{
		if(MotorA.rotationCounterFlag)
		{
			MotorA.rotCnt++;
			*MotorA.rotationCounter = (float )MotorA.rotCnt / 360;
			*MotorA.pOCR = 1;
			*MotorA.pTCNT = 0;
			*MotorA.pTIFR = 0;
		}
	}
	interrupts();
}

ISR(TIMER1_COMPA_vect) 
{
  noInterrupts();
  if(MotorB.state == ALGOMOTOR_STATE_ROTATION)
  {
	  MotorB.stop();
  }
  else
  {
	  if(MotorB.rotationCounterFlag)
	  {
		  MotorB.rotCnt++;
		  *MotorB.rotationCounter = (float )MotorB.rotCnt / 360;
		  *MotorB.pOCR = 1;
		  *MotorB.pTCNT = 0;
		  *MotorB.pTIFR = 0;
		}

  }
  interrupts();
}

ISR(TIMER4_COMPA_vect) 
{
  noInterrupts();
  if(MotorC.state == ALGOMOTOR_STATE_ROTATION)
  {
	  MotorC.stop();
  }
  else
  {
	  if(MotorC.rotationCounterFlag)
	  {
		  MotorC.rotCnt++;
		  *MotorC.rotationCounter = (float )MotorC.rotCnt / 360;
		  *MotorC.pOCR = 1;
		  *MotorC.pTCNT = 0;
		  *MotorC.pTIFR = 0;
	  }

  }
  interrupts();
}



/* ***************************** END OF FILE ******************************* */
