/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOWAIT_H
#define __ALGOWAIT_H

/* Includes **************************************************************** */
#include <Arduino.h>
#include <algothread.h>

/* Exported constants ****************************************************** */

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

/* Exported functions ****************************************************** */
void Wait(float period);
uint8_t Wait(AlgoThread & thread,float period);

#endif 
/* ***************************** END OF FILE ******************************* */

