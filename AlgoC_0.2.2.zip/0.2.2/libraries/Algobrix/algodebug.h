/* Define to prevent recursive inclusion *********************************** */
#ifndef __ALGOLIGHT_H
#define __ALGOLIGHT_H

/* Includes **************************************************************** */
#include <Arduino.h>

/* Exported constants ****************************************************** */

/* Exported macros ********************************************************* */

/* Exported types ********************************************************** */

/* Exported variables ****************************************************** */

void __break_point(void);
void __break_point(char breakChar);

/* Exported functions ****************************************************** */

#endif 
/* ***************************** END OF FILE ******************************* */


